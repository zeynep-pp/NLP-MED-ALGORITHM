
import java.util.Scanner;  // Import the Scanner class
import java.io.IOException;
import org.javatuples.Quartet; //references https://jar-download.com/artifacts/org.javatuples/javatuples/1.2/source-code
import org.apache.commons.lang.time.StopWatch; // references: http://www.java2s.com/Code/Jar/a/Downloadapachecommonslangjar.htm

class Test
{
	    
    
        public static int medFunction(String string1, String string2, int m, int n)
        {
            // Create a table to store  results of subproblems 
            int[][] dp = new int[m + 1] [n + 1];
            int insert = 0;
            int remove = 0;
            int replace = 0;

            // Fill d[][] in bottom up manner 
             for (int i = 0; i <= m; i++)
            {
                for (int j = 0; j <= n; j++)
                {
                    if (i == 0)
                        {
                        dp[i][j] = j;
                        System.out.print(j);
                        if(j == 0)
                            {System.out.print("|");}
                        }
                }
            }
            System.out.println();
            for (int j = 0; j <= n; j++)
                {
                        System.out.print("--");
                }
            for (int i = 0; i <= m; i++)
            {
                for (int j = 0; j <= n; j++)
                {
                    // If first string is empty, only option is to insert all characters of second string 
                    if (i == 0)
                        {}
                    // If second string is empty, only option is to  remove all characters of second string 
                    else if (j == 0)
                        {dp[i][j] = i;
                        System.out.print(i + "|");}


                 // If the last characters are the same, ignore the last character and repeat for the remaining string
                    else if (string1.substring(string1.length() - 1) == string2.substring(string2.length() - 1))
                        {dp[i][ j] = dp[i - 1][ j - 1];
                        System.out.print(dp[i][ j]);}

                    // If the last character is different, consider all possibilities and find the minimum 
                    else
                        {
                    	Quartet<Integer, Integer, Integer, Integer> quartet = min(dp[i][ j - 1], dp[i - 1][ j], dp[i - 1][j - 1], insert, remove, replace);
                        dp[i][ j] = 1 + quartet.getValue0();
                        insert = quartet.getValue1();
                        remove = quartet.getValue2();
                        replace = quartet.getValue3();
                        
                        System.out.print(dp[i][ j]);}
                }
                System.out.println();
            }
            System.out.println();
            System.out.println("insert: "+ insert +", remove: "  + remove + ", replace: "+ replace );

            
            return dp[m][ n];
        }

        public static  Quartet<Integer, Integer, Integer, Integer> min(int x, int y, int z, int insert, int remove, int replace)
        {
            if (x <= y && x <= z) {insert ++; return Quartet.with(x,insert,remove,replace);}
            if (y <= x && y <= z) {remove ++; return Quartet.with(y,insert,remove,replace);}
            else {replace++; return Quartet.with(z,insert,remove,replace);}
        }
        public static void main(String[] args) throws IOException  
        {
    	    Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        	while (true) {
                //var watch = new Stopwatch();
                StopWatch timer = new StopWatch();
                timer.start();
                System.out.println();
                System.out.print("Enter first word:");
                String word1 = myObj.nextLine();
                System.out.print("Enter second word:");
                String word2 = myObj.nextLine();
                System.out.println();
                System.out.println("MED Value");
                System.out.println();
                int med = medFunction(word1, word2, word1.length(), word2.length());
                System.out.println("MED value: " + med);
                System.out.println();
                timer.stop();
                System.out.println("Execution Time: "+ timer );
                System.out.println("----------------------------------------------------------------------");
			}

    	 


        }

    
}
